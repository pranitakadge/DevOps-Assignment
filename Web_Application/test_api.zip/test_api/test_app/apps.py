from django.apps import AppConfig


class InfraApiConfig(AppConfig):
    name = 'test_app'
