# Django related dependencies
from django.http import HttpResponse

def home(request):
   return HttpResponse("Congratulation!! It's Working Kindly Use correct URL for Services")
